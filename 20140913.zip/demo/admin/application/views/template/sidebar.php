  
			<!-- sidebar -->
            <a href="javascript:void(0)" class="sidebar_switch on_switch ttip_r" title="Hide Sidebar">Sidebar switch</a>
            <div class="sidebar">
				
				<div class="antiScroll">
					<div class="antiscroll-inner">
						<div class="antiscroll-content">
					
							<div class="sidebar_inner">
								<div id="side_accordion" class="accordion">
									
									<!--<div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseOne" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-folder-close"></i> Content
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseOne">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)">Articles</a></li>
													<li><a href="javascript:void(0)">News</a></li>
													<li><a href="javascript:void(0)">Newsletters</a></li>
													<li><a href="javascript:void(0)">Comments</a></li>
												</ul>
											</div>
										</div>
									</div>
									<div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseTwo" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-th"></i> Modules
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseTwo">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)">Content blocks</a></li>
													<li><a href="javascript:void(0)">Tags</a></li>
													<li><a href="javascript:void(0)">Blog</a></li>
													<li><a href="javascript:void(0)">FAQ</a></li>
													<li><a href="javascript:void(0)">Formbuilder</a></li>
													<li><a href="javascript:void(0)">Location</a></li>
													<li><a href="javascript:void(0)">Profiles</a></li>
												</ul>
											</div>
										</div>
									</div>-->
									<!--<div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseThree" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Account manager
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseThree">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)">Members</a></li>
													<li><a href="javascript:void(0)">Members groups</a></li>
													<li><a href="javascript:void(0)">Users</a></li>
													<li><a href="javascript:void(0)">Users groups</a></li>
												</ul>
												
											</div>
										</div>
									</div>-->
									<!--<div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseFour" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-cog"></i> Configuration
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseFour">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li class="nav-header">People</li>
													<li class="active"><a href="javascript:void(0)">Account Settings</a></li>
													<li><a href="javascript:void(0)">IP Adress Blocking</a></li>
													<li class="nav-header">System</li>
													<li><a href="javascript:void(0)">Site information</a></li>
													<li><a href="javascript:void(0)">Actions</a></li>
													<li><a href="javascript:void(0)">Cron</a></li>
													<li class="divider"></li>
													<li><a href="javascript:void(0)">Help</a></li>
												</ul>
											</div>
										</div>
									</div>-->
									
									<!--<div class="accordion-group">
										<div class="accordion-heading">
											<a href="javascript:void(0);" class="accordion-toggle" onclick="window.open('<?php echo base_url(); ?>Banner/','_top');"><i class="icon-cog"></i> Banner Images</a>
										</div>																		
									</div>	-->	
									
									<div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseFive" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Banner Images
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseFive">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>banner/addBanner','_top');">Add</a></li>
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>banner/listBanner','_top');">List</a></li>
												</ul>
												
											</div>
										</div>
									</div>
									
									<div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseSix" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Categories
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseSix">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>category/addCategory','_top');">Add</a></li>
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>category/listCategory','_top');">List</a></li>
												</ul>
												
											</div>
										</div>
									</div>
                                    
                                    <div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseTwo" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Vendors
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseTwo">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>vendor/addVendor','_top');">Add</a></li>
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>vendor/listVendors','_top');">List</a></li>
                                                </ul>
												
											</div>
										</div>
									</div>
                                    
                                    <div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseOne" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Attributes
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseOne">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>product/addColor','_top');">Colors</a></li>
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>product/addSize','_top');">Size</a></li>
                                                    <li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>product/addBrand','_top');">Brands</a></li>
												</ul>
												
											</div>
										</div>
									</div>
                                    
                                    <div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseSeven" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Products
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseSeven">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>product/addProduct','_top');">Add</a></li>
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>product/listProducts','_top');">List</a></li>
												</ul>
												
											</div>
										</div>
									</div>
                                    
                                    <div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseEight" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Orders
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseEight">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>orders/listOrders','_top');">List</a></li>
                                                    <li><a href="javascript:void(0)" onclick="javascript:void(0);">Orders from Amazon</a></li>
                                                    <li><a href="javascript:void(0)" onclick="javascript:void(0);">Orders from eBay</a></li>
                                                    <li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>orders/traceOrder','_top');">Trace Order/ Shipping info</a></li>
												</ul>
												
											</div>
										</div>
									</div>
                                    
                                    <!--<div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseNine" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Newsletter Subscribers
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseNine">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>newsletters/subscribers','_top');">List</a></li>
												</ul>
												
											</div>
										</div>
									</div>-->
                                    
                                    <div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseTen" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Pages
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseTen">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>page/add','_top');">Add Page</a></li>
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>page/staticPages','_top');">List Pages</a></li>
												</ul>
												
											</div>
										</div>
									</div>
                                    
                                    <div class="accordion-group">
										<div class="accordion-heading">
											<a href="#collapseEleven" data-parent="#side_accordion" data-toggle="collapse" class="accordion-toggle">
												<i class="icon-user"></i> Mail Content
											</a>
										</div>
										<div class="accordion-body collapse" id="collapseEleven">
											<div class="accordion-inner">
												<ul class="nav nav-list">
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>mailContent/addMailContent','_top');">Add Content</a></li>
													<li><a href="javascript:void(0)" onclick="window.open('<?php echo base_url(); ?>mailContent/listContent','_top');">List Content</a></li>
												</ul>
												
											</div>
										</div>
									</div>
									
									<!--<div class="accordion-group">
										<div class="accordion-heading">
											<a href="javascript:void(0);" class="accordion-toggle" onclick="window.open('<?php echo base_url(); ?>Featured/addCategory','_top');"><i class="icon-cog"></i> </a>
										</div>																		
									</div>		-->															
																								
								</div>
								
								
								
								
								<div class="push"></div>
							</div>
							   
						</div>
					</div>
				</div>
			
			</div>
            
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/jquery.min.js"></script>
			<!-- smart resize event -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/jquery.debouncedresize.min.js"></script>
			<!-- hidden elements width/height -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/jquery.actual.min.js"></script>
			<!-- js cookie plugin -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/jquery.cookie.min.js"></script>
			<!-- main bootstrap js -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>bootstrap/js/bootstrap.min.js"></script>
			<!-- tooltips -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/qtip2/jquery.qtip.min.js"></script>
			<!-- jBreadcrumbs -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/jBreadcrumbs/js/jquery.jBreadCrumb.1.1.min.js"></script>
			<!-- lightbox -->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/colorbox/jquery.colorbox.min.js"></script>
            <!-- fix for ios orientation change -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/ios-orientationchange-fix.js"></script>
			<!-- scrollbar -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/antiscroll/antiscroll.js"></script>
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/antiscroll/jquery-mousewheel.js"></script>
			<!-- common functions -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/gebo_common.js"></script>
			
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/jquery-ui/jquery-ui-1.8.20.custom.min.js"></script>
            <!-- touch events for jquery ui-->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/forms/jquery.ui.touch-punch.min.js"></script>
            <!-- multi-column layout -->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/jquery.imagesloaded.min.js"></script>
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/jquery.wookmark.js"></script>
            <!-- responsive table -->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/jquery.mediaTable.min.js"></script>
           
		    
		   
		    <!-- calendar -->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/fullcalendar/fullcalendar.min.js"></script>
            <!-- sortable/filterable list -->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/list_js/list.min.js"></script>
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/list_js/plugins/paging/list.paging.min.js"></script>
			
			
			<!-- common functions -->
			<script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/gebo_common.js"></script>
			
			 <!-- datatable -->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/datatables/jquery.dataTables.min.js"></script>
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>lib/datatables/extras/Scroller/media/js/Scroller.min.js"></script>
           
		    <!-- dashboard functions -->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>js/gebo_datatables.js"></script>
    
			<!-- My functions -->
            <script src="<?php echo $this->config->item('css_images_js_base_url'); ?>functions/functions.js"></script>
    
			<script>
				$(document).ready(function() {
					//* show all elements & remove preloader
					setTimeout('$("html").removeClass("js")',1000);
				});
			</script>
		
		</div>
	</body>
</html>